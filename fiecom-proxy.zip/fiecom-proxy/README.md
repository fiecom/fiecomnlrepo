
# Fiecom Proxy (Vercel)

## Doel
Proxy voor:
- fiecom.nl → Base44 homepage
- www.fiecom.nl → Base44 homepage
- klant.fiecom.nl → https://fiecom.base44.app/?site=klant

## Deploy
1. Upload ZIP naar Vercel (Import Project).
2. Deploy.
3. Domeinen koppelen:
   - fiecom.nl
   - www.fiecom.nl
   - *.fiecom.nl
