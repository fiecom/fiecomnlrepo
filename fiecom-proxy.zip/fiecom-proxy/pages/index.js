
export async function getServerSideProps() {
  return {
    redirect: {
      destination: "https://fiecom.base44.app/",
      permanent: false
    }
  };
}

export default function Home() {
  return "Redirecting...";
}
