
export async function getServerSideProps({ req }) {
  const host = req.headers.host;
  const sub = host.split(".")[0];

  if (sub === "www" || sub === "fiecom") {
    return {
      redirect: { destination: "https://fiecom.base44.app/", permanent: false }
    };
  }

  return {
    redirect: {
      destination: `https://fiecom.base44.app/?site=${sub}`,
      permanent: false
    }
  };
}

export default function CatchAll() {
  return "Redirecting...";
}
